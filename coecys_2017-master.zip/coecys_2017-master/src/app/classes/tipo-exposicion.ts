export class TipoExposicion {
    id?:string;
    description:any;

    constructor(description:any){
        this.description = description;
    }
}
