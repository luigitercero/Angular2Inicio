import { TipoExposicion } from '../classes/tipo-exposicion';

export let TIPO_EXPOSICIONES:TipoExposicion[] = [
    {
        id:'1',
        description:'Conferencia'
    },
    {
        id:'2',
        description: 'Taller'
    }
]